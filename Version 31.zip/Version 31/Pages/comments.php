<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

session_start();
error_reporting(1);
// store the username of the user in variable to use it
$name = $_SESSION['username'];
// PHP variables that store the details of the comment to insert it in the comments table in database
	$email=$_POST['email'];
	$content=$_POST['content'];
	$query = "INSERT INTO comments(name,email,content) 
	VALUES ( '$name','$email','$content');";

// query that insert the comment id and the username in writes table (writes is a relation between tables of the user and comments)
	if (mysqli_query($conn, $query )) {

		$last_id = mysqli_insert_id($conn); 
        $sql=" INSERT INTO writes (username,comment_id) VALUES('$name','$last_id');";
		mysqli_query($conn, $sql );
// if the data not inserted we print data failed
	} 
	else {
	echo "data failed";
	}


?>
 