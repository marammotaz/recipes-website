<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

session_start();
error_reporting(1);


// PHP varaibles to use them in the queries
	$ID=$_POST['ID'];
	$Name=$_POST['Name'];
	$rating=$_POST['rating'];
    $img=$_POST['img'];
	$Nationality=$_POST['Nationality'];
	$NumberOfRecipes=$_POST['NumberOfRecipes'];
    $Books=$_POST['Books'];
	$book2=$_POST['book2'];
	$book3=$_POST['book3'];
    $Description=$_POST['Description'];
	
// make the username of the admin  global variable to use as a foreign key in chef tables
	$sql = "SELECT * FROM admin";
	$result = mysqli_query($conn, $sql);
	
	while ($row = $result->fetch_assoc()) {
	   $_SESSION['username'] = $row['username'];

	}
	$username= $_SESSION['username'];

// insert values of the columns of chefs  table 
//with the PHP varaibles values that we get them from the values of the input s in the add chef card.
	$sql2 = "INSERT INTO chefs(ID, Name,rating,img,Nationality,NumberOfRecipes,Books,book2 ,book3,Description,username) 
	
	VALUES ('$ID','$Name','$rating' ,'$img','$Nationality','$NumberOfRecipes','$Books','$book2','$book3','$Description','$username');";


// print data inserted if the query is ture and data failed if not
	if (mysqli_query($conn, $sql2)) {

	echo "data inserted";
	} 
	else {
	echo "data failed";
	}

?>