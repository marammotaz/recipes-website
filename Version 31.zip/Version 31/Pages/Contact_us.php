<?php

//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

session_start();

// Check whether the user has previously login before proceeding to this page or not
if (!isset($_SESSION['username'])) {
  header("Location: signin.php");
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Contact us</title>
  <link rel="stylesheet" href="../Styles/contact.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
  <!-- Includes the navbar -->
  <?php include 'navbar.php' ?>
  <!-- Here is the div that contain the img and headers which are in the top of the page -->
  <div class="contact-img">

    <div class="blurBack"> Contact us </div>
  </div>
  <div class="afterImg">

    <div class="Help">How can we help?</div>

    <div class="all-logos">
      <div>You Can Send Us a Message </div>


    </div>
    <div class="flex-content">
      <!-- Here is the iframe that we embed the google maps in the page  by it -->
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d110502.60389574402!2d31.18842370763649!3d30.05961847009344!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14583fa60b21beeb%3A0x79dfb296e8423bba!2sCairo%2C%20Cairo%20Governorate!5e0!3m2!1sen!2seg!4v1649803478262!5m2!1sen!2seg" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

      <div class="beforeGrid">


        <!-- Here is the form that the user can write the comments in it with the user details -->
        <form id='fupForm' action="" method="POST">
          <div id="content">
            <div class="marg"></div>
            <h2 class="align-top">Get Touch With Us</h2>
            <br>

            <!-- input of the email of the user -->
            <div class="group">
              <input type="email" required class="form-input" id='email' name='email' />
              <span class="highlight"></span>
              <span class="barContact"></span>
              <label>Email</label>
            </div>
            <!-- the input of the comment of the user -->
            <div class="group">

              <input type="text" required class="form-input" id='message' name='content' />
              <span class="highlight"></span>
              <span class="barContact"></span>
              <label>Enter your message...</label>

            </div>
            <button class="btn" name='submit' id='butsave'>Submit</button>
            <br>
            <br>
          </div>
        </form>
      </div>
    </div>
  </div>
  </div>
  <?php include 'footer.php' ?>

  <!-- This script is used to make button contact in the navbar in a different color -->
  <script>
    var contact = document.getElementById('contact');
    contact.style.color = "#555";

    $(document).ready(function() {
      $("#butsave").click(function() {

        //This ajax function used to post the details of the comment to send it to the admin page
        var email = $("#email").val();
        var content = $("#message").val();

        $.ajax({
          url: 'comments.php',
          method: 'POST',
          data: {

            email: email,
            content: content
          },
          success: function(data) {
            alert("Seccessfull");
          }
        });
      });
    });
  </script>
</body>

</html>