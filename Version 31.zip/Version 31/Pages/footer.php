<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../Styles/footer.css" />
    <title>Footer</title>
  </head>
  <body>
		<!-- Here is the footer shown at the bottom of pages -->
    <div class="footerstyle">
			<br>
			<!-- Here is the title of the footer -->
			<h1 class="footcenter">About Us</h1>
      <div class="fox">
				<!-- Here is the first item in the footer -->
				<div class="footitem">
					<div class="footcenter">
						<h2>Remy's</h2>
					</div>
					<div>
						<p class="footabout">
							Remy's is a recipe website, where you can navigate between many delicious recipes made by professional chefs. You can choose your own category,
							navigate between all recipes, choose your favourite recipe to show you how to make it. Moreover, you can see all the chefs registered
							with us and choose your favourite one to review all his/her recipes. You can also add your starred recipes to your profile to easily see them later.
						</p>
					</div>
				</div>
				<!-- Here is the second item in the footer -->
				<div class="footitem">
					<div class="footcenter">
						<h2>Locations</h2>
					</div>		
					<ul>
						<li class="footabout">
							Villa 102, Lotus, First Settlement, Cairo, Egypt
						</li>
						<br/><br/>
						<li class="footabout">
							Villa 2, Hilal Compound, Sheikh Zayed, Cairo, Egypt
						</li>
						<br/><br/>
						<li class="footabout">
							Appartment 3, Building A, Nozha Street,<br/> Masr El-Gedida, Cairo, Egypt
						</li>
					</ul>
				</div>
				<!-- Here is the third item in the footer -->
				<div class="footitem">
					<div class="footcenter">
						<h2>Quick Contact</h2>
					</div>
					<img src="../Media/phone.png" alt="phone" class="phone-mail">
					<h3 class="footabout pic">
						Phone:
					</h3>
					<ul>
						<li class="footabout">
							(+20)1156789854
						</li>
						<li class="footabout">
							(02)2457894550
					</ul>
					<br/>
					<img src="../Media/mail.png" alt="mail" class="phone-mail">
					<h3 class="footabout pic">
						Email:
					</h3>
					<ul>
						<li class="footabout">
							remys@yahoo.com
						</li>
						<li class="footabout">
							support_remys@gmail.com
					</ul>
				</div>	
      </div>
      <br />
			<!-- Here is the line seperating social media buttond from above -->
      <hr class="hr-style" />
			<!-- Here are the logos of the social media related to our website -->
			<div class="footcenter">
				<span class="opac">Copyright @2022 | Designed by Remy's</span>
				<br/>
				<a href="https://www.facebook.com/" target="_blank"><img src="../Media/facebook.png" alt="facebook" class="logo"/></a>
				<a href="https://www.instagram.com/" target="_blank"><img src="../Media/instagram.png" alt="instagram" class="logo"/></a>
				<a href="https://twitter.com/" target="_blank"><img src="../Media/twitter.png" alt="twitter" class="logo"/></a>
				<a href="https://www.linkedin.com/" target="_blank"><img src="../Media/linkedin.png" alt="linkedin" class="logo"/></a>
			</div>
      <br />
    </div>
  </body>
</html>
