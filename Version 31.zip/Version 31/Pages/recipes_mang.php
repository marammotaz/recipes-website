<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

//variables to them in query when user wants to search, filter, sort recipes 
$filter = $_POST['filter'];
$sort = $_POST['sort'];
$text = $_POST['text'];

// Select from query whenever the user wants to search/filter/sort the recipes and make query for each 
$query = "SELECT * FROM recipe where `Name`LIKE '%{$text}%'";
if($filter=="nofilter"){
  if ($sort == "def") {
    $query = "SELECT * FROM recipe where `Name`LIKE '%{$text}%'";
  } else {
    $query = "SELECT * FROM recipe where `Name`LIKE '%{$text}%' ORDER BY `Name` $sort";
  } 
}
else{
  if ($sort == "def") {
    $query = "SELECT * FROM recipe where `Name`LIKE '%{$text}%' and `filter`='$filter'";
  } else {
    $query = "SELECT * FROM recipe where `Name`LIKE '%{$text}%' and `filter`='$filter' ORDER BY `Name` $sort";
  } 
}

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {


  while ($row = mysqli_fetch_array($result)) {
    // cards of recipes created according to the query
    echo "<div class='allrec-cards'>
            <div>  <img  class=\"allRec-bkgrndImg\" src='" . $row['img'] . "' /></div>
            <div class='allRec-container'>
              <h3>" . $row['Name'] . "  </h3>
              <hr class='spearatename'>
              <ul class='ul-allrec'>
                <li class='ListRec'><i class='fas fa-clock'></i>" . $row['time'] . " </li>
                <li class='ListRec'><i class='fas fa-book-open'></i>
                  Ingredients </li>
                <li class='ListRec'> <i class='fas fa-user'></i >" . $row['serve'] . "</li> </ul>
              <div class='allRec-card-content'>
              <p> " . $row['Description'] . "</p>
              </div>

              <a href=\"ClickRecipe.php?ID_Rec=" . $row['ID_Rec'] . "\">
                <button >View Recipe</button> </a>
              </ul>
            </div>
          </div>";
  }
} else {
  // when recipe is not found 
  echo "<h6 class='text-danger' style=' margin-left:50px; font-size:30px; color: #2d3e50; font-style: italic'>No DATA FOUND !</h6>";
}
