<?php

session_start();

//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

// Check whether the user has previously login before proceeding to this page or not
if (!isset($_SESSION['username'])) {
  header("Location: signin.php");
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>All Recipes</title>
  <link rel="stylesheet" href="../Styles/AllRecipe.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="search.js" defere></script>
</head>

<body class="AllRecipies">
  <?php include 'navbar.php'; ?>
  <!-- Image Holding the next Nav Bar the Second Nav Bar -->
  <div class="allrecmain-img"></div>
  <div class="menu-bar">
    <select name="sort" id="sort">
      <option value="def">Default</option>
      <option value="ASC">A-Z</option>
      <option value="DESC">Z-A</option>
    </select>
    <select name="filer" id="filter">
      <option value="nofilter">No Filter</option>
      <option value="pop">Most Popular</option>
      <option value="view">Most Viewed</option>
    </select>
    <div class="minibar">
      <input type="text" placeholder="Search on Remy's" name="key" class="search" id="liveSearch" />
      <button type="submit" class="search-ic">
        <i class="fa fa-search fa-2x icc"></i>
      </button>
    </div>
  </div>

  <br><br><br>
  <!--The END Background with the second nav bar-->


  <!--The FOOD CARDS-->

  <!--First FOOD CARDS-->
  <div class="AllAllRec" id="container-cards"></div>
  <?php include "footer.php"; ?>

  <!-- This script is used to make button recipes in the navbar in a different color -->
  <script>
    var recipes = document.getElementById('recipes');
    recipes.style.color = "#555";
  </script>


  <!-- This script is used to get all the cards -->
  <script type="text/javascript">
    $(document).ready(function() {
      $.ajax({
        url: "recCard.php",
        method: "POST",
        data: {
          category: "<?php echo " " . $_GET['category'] . "" ?>"
        },
        success: function(response) {
          $("#container-cards").html(response);
        }
      });
    });
  </script>
  <!-- Sort, Search, Filter -->
  <script type="text/javascript">
    $(document).ready(function() {

      $("#sort").on('change', function() {
        var sort = $(this).val();
        var filter = $('#filter').val();
        var text = $('#liveSearch').val();

        $.ajax({
          url: "recipes_mang.php",
          method: "POST",
          data: {
            sort: sort,
            filter: filter,
            text: text
          },

          success: function(data) {
            $("#container-cards").html(data);
          }
        })
      });
    });

    // Filter by Most Popular and Most Viewd
    $(document).ready(function() {
      $("#filter").on('change', function() {
        var filter = $(this).val();
        var sort = $('#sort').val();
        var text = $('#liveSearch').val();

        $.ajax({
          url: "recipes_mang.php",
          method: "POST",
          data: {
            filter: filter,
            sort: sort,
            text: text
          },

          success: function(data) {
            $("#container-cards").html(data);
          }
        })
      });
    });

    // Search for specfic recipe, get recipes from database
    $(document).ready(function() {

      $("#liveSearch").keyup(function() {
        var text = $(this).val();
        var filter = $('#filter').val();
        var sort = $('#sort').val();

        $.ajax({
          url: "recipes_mang.php",
          method: "POST",
          data: {
            sort: sort,
            filter: filter,
            text: text
          },

          success: function(data) {
            $("#container-cards").html(data);
          }
        })

      });


    });
  </script>



</body>

</html>