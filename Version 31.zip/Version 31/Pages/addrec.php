<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';



// PHP varaibles to use them in the queries
	$ID_Rec=$_POST['ID_Rec'];
	$Name=$_POST['Name'];
    $img=$_POST['img'];
	$time=$_POST['time'];
	$serve=$_POST['serve'];
    $Description=$_POST['Description'];
    $preptime=$_POST['preptime'];
    $INGREDIENT1=$_POST['INGREDIENT1'];
	$INGREDIENT2=$_POST['INGREDIENT2'];
	$INGREDIENT3=$_POST['INGREDIENT3'];
	$INGREDIENT4=$_POST['INGREDIENT4'];
	$INGREDIENT5=$_POST['INGREDIENT5'];
	$INGREDIENT6=$_POST['INGREDIENT6'];
	$INGREDIENT7=$_POST['INGREDIENT7'];

    $Tool1=$_POST['Tool1'];
	$Tool2=$_POST['Tool2'];
	$Tool3=$_POST['Tool3'];
	$Tool4=$_POST['Tool4'];

    $INSTRUCTION1=$_POST['INSTRUCTION1'];
	$INSTRUCTION2=$_POST['INSTRUCTION2'];
	$INSTRUCTION3=$_POST['INSTRUCTION3'];


    $NUTRITIONFACT1=$_POST['NUTRITIONFACT1'];
	$NUTRITIONFACT2=$_POST['NUTRITIONFACT2'];
	$NUTRITIONFACT3=$_POST['NUTRITIONFACT3'];
	$NUTRITIONFACT4=$_POST['NUTRITIONFACT4'];
	$NUTRITIONFACT5=$_POST['NUTRITIONFACT5'];
	$NUTRITIONFACT6=$_POST['NUTRITIONFACT6'];
	$chef_id=$_POST['chef_id'];
    $category=$_POST['category'];
	$Filter=$_POST['Filter'];

	// // insert values of the columns of recipe table 
//with the PHP varaibles values that we get them from the values of the inputs.

	$sql = "INSERT INTO recipe(ID_Rec, Name,img,time,serve,Description,preptime,category,INSTRUCTION1,INSTRUCTION2,INSTRUCTION3,INGREDIENT1,INGREDIENT2,INGREDIENT3,INGREDIENT4,INGREDIENT5,
	INGREDIENT6,INGREDIENT7,Tool1,Tool2,Tool3,Tool4,NUTRITIONFACT1
	,NUTRITIONFACT2,NUTRITIONFACT3,NUTRITIONFACT4,NUTRITIONFACT5,NUTRITIONFACT6,Filter,chef_id) 

	VALUES ('$ID_Rec','$Name','$img','$time','$serve','$Description','$preptime','$category','$INSTRUCTION1','$INSTRUCTION2','$INSTRUCTION3','$INGREDIENT1','$INGREDIENT2',
	'$INGREDIENT3','$INGREDIENT4','$INGREDIENT5','$INGREDIENT6','$INGREDIENT7','$Tool1','$Tool2','$Tool3','$Tool4'
	,
	'$NUTRITIONFACT1','$NUTRITIONFACT2','$NUTRITIONFACT3','$NUTRITIONFACT4','$NUTRITIONFACT5','$NUTRITIONFACT6','$Filter',$chef_id)";
	
// print data inserted if the query is ture and data failed if not
	if (mysqli_query($conn, $sql)) {
	echo "data inserted";
	} 

	else {
	echo "data failed";
	}

?>