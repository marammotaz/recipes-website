<?php
header("Content-type: text/css");
?>
<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

/* selecting all from recipe table according to the
 category to display recipes with specific category from the categories that are in home page as
 breakfast, lunch, desserts, beverages, snacks and salad
 */

$sql = "SELECT * FROM recipe";

$category = $_POST['category'];
/* check on the categories to select recipes from database */
if ($category == " Breakfast") {
  $sql = "SELECT * FROM recipe where `category`='Breakfast'";
} else if ($category == " Lunch") {
  $sql = "SELECT * FROM recipe where `category`='Lunch'";
} else if ($category == " Desserts") {
  $sql = "SELECT * FROM recipe where `category`='Desserts'";
} else if ($category == " Beverages") {
  $sql = "SELECT * FROM recipe where `category`='Beverages'";
} else if ($category == " Snacks") {
  $sql = "SELECT * FROM recipe where `category`='Snacks'";
} else if ($category == " salad") {
  $sql = "SELECT * FROM recipe where `category`='salad'";
}


$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_array($result)) {
    // create cards of all recipes with the specified category with img, name , time , serve , description and button for more details
    echo "<div class='allrec-cards'>
            <div>  <img  class=\"allRec-bkgrndImg\" src='" . $row['img'] . "' /></div>
            <div class='allRec-container'>
              <h3>" . $row['Name'] . "</h3>
              <hr class='spearatename'>
              <ul class='ul-allrec'>
                <li class='ListRec'><i class='fas fa-clock'></i>" . $row['time'] . " </li>
                <li class='ListRec'><i class='fas fa-book-open'></i>
                  Ingredients </li>
                <li class='ListRec'> <i class='fas fa-user'></i >" . $row['serve'] . "</li> </ul>
              <div class='allRec-card-content'>
              <p> " . $row['Description'] . "</p>
              </div>
              <p class='cheffID'> Made By Chef ID: "  . $row['chef_id'] . "</p>
              <a href=\"ClickRecipe.php?ID_Rec=" . $row['ID_Rec'] . "\">
                <button >View Recipe</button> </a>
              </ul>
            </div>
          </div>";
  }
} else {
  echo "<h6 class='text-danger' style=' margin-left:50px; font-size:30px'>No DATA FOUND</h6>";
}
?>

  