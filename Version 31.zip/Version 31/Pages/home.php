<?php

session_start();

// Check whether the user has previously login before proceeding to this page or not
if (!isset($_SESSION['username'])) {
  header("Location: signin.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../Styles/home.css" />
  <title>Home</title>
</head>

<body class="home">
  <!-- Includes the navbar -->
  <?php include 'navbar.php' ?>

  <!-- Here is the animation of the scrolling images -->
  <div class="Animation">
    <div class="contentt">
      <p class="textAnimation">
        Discover Professional Cooking tips & Recipes
      </p>
    </div>
  </div>

  <!-- Here is the cards indicating the type of meals are shown -->
  <div>
    <h2 class="meal-name" id="title-cat">Categories</h2>
    <div class="flex-box">
      <div class="card">
        <a href="AllRecipes.php?category=Breakfast"><img src="../Media/breakfast-com.jpg" alt="Avatar" class="img" /></a>
        <div class="centered">
          <h2 class="meal-name">Breakfast</h2>
        </div>
      </div>
      <div class="card">
        <a href="AllRecipes.php?category=Lunch"><img src="../Media/lunch-com.jpg" alt="Avatar" class="img" /></a>
        <div class="centered">
          <h2 class="meal-name">Lunch</h2>
        </div>
      </div>
      <div class="card">
        <a href="AllRecipes.php?category=Beverages"><img src="../Media/drinks-com.jpg" alt="Avatar" class="img" /></a>
        <div class="centered">
          <h2 class="meal-name">Beverages</h2>
        </div>
      </div>
      <div class="card">
        <a href="AllRecipes.php?category=Desserts"><img src="../Media/dessert-com.jpg" alt="Avatar" class="img" /></a>
        <div class="centered">
          <h2 class="meal-name">Desserts</h2>
        </div>
      </div>
      <div class="card">
        <a href="AllRecipes.php?category=Snacks"><img src="../Media/snacks-com.jpg" alt="Avatar" class="img" /></a>
        <div class="centered">
          <h2 class="meal-name">Snacks</h2>
        </div>
      </div>
      <div class="card">
        <a href="AllRecipes.php?category=salad"><img src="../Media/salads-com.jpg" alt="Avatar" class="img" /></a>
        <div class="centered">
          <h2 class="meal-name">Salads</h2>
        </div>
      </div>
    </div>
  </div>
  <div class="marg"></div>

  <!-- Includes the footer -->
  <?php include 'footer.php' ?>

  <!-- This script is used to make button home in the navbar in a different color -->
  <script>
    var home = document.getElementById('home');
    home.style.color = "#555";
  </script>

</body>

</html>