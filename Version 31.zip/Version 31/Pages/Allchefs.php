<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>All chefs</title>
  <link rel="stylesheet" href="../Styles/chefs.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
  <!-- Includes the navbar -->
  <?php include 'navbar.php'; ?>
  <div class="allCards" id='card_response'> </div>
  <!-- Includes the footer -->
  <?php include 'footer.php'; ?>
  <script>
    var chefs = document.getElementById('chefs');
    chefs.style.color = "#555";
  </script>

  <script>
    $(document).ready(function(){
    // here is the ajax function that we use to get the details of every chef to display them 
                $.ajax({
                    url:'chefCard.php',
                    method:'GET',
                   
                   success:function(response){
                    $("#card_response").html(response); 
                   }
                });
            
        });
    </script>
</body>

</html>
