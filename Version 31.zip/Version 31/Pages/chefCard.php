<?php
    header("Content-type: text/css");
?>
<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

$sql = "SELECT * FROM chefs" ;
$result = mysqli_query($conn, $sql) ;
//fetching data of chefs from chefs table in database and put it in a card with img, name, rating and details link 
while( $row = $result ->fetch_assoc()){

  //the if conditions to handle the icons of the rating bar
  if($row['rating'] == 1)  {
    /* creating the cards of the chefs with their img, name, rating with rating icons,
     link to more details about the chef that will redirect to page chef.php with the details according to the ID */
    echo "
    <div class=\"allCards\">

    <div class=\"cards\">
    <div > <img  class=\"chef-img\" src='". $row['img']."' /></div> 
      <div class=\"container\">
        <h4>". $row['Name'] ." ID=".$row['ID']."</h4>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        
        <div class=\"MoreInfo\"><a href=\"chef.php?ID=". $row['ID'] ."\">Details</a></div>
      </div>
    </div>
  
    
  </div>
    ";
}
  if($row['rating'] == 2)  {
    echo "
    <div class=\"allCards\">

    <div class=\"cards\">
    <div > <img  class=\"chef-img\" src='". $row['img']."' /></div> 
      <div class=\"container\">
        <h4>". $row['Name'] ." ID=".$row['ID']."</h4>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <div class=\"MoreInfo\"><a href=\"chef.php?ID=". $row['ID'] ."\">Details</a></div>
      </div>
    </div>
  
    
  </div>
    ";
}
    if($row['rating'] == 3)  {
    echo "
    <div class=\"allCards\">

    <div class=\"cards\">
    <div > <img  class=\"chef-img\" src='". $row['img']."' /></div> 
      <div class=\"container\">
        <h4>". $row['Name'] ." ID=".$row['ID']." </h4> 
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <div class=\"MoreInfo\"><a href=\"chef.php?ID=". $row['ID'] ."\">Details</a></div>
      </div>
    </div>
  
    
  </div>
    ";
}
else if( $row['rating'] == 4)
{
    echo "
    <div class=\"allCards\">

    <div class=\"cards\">
    <div>  <img class=\"chef-img\" src='". $row['img']."' /></div> 
      <div class=\"container\">
      
        <h4>". $row['Name'] ." ID=".$row['ID']."</h4>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <div class=\"MoreInfo\"><a href=\"chef.php?ID=". $row['ID'] ."\">Details</a></div>
      </div>
    </div>
  
    
  </div>
    "
   ;
} 
else if( $row['rating'] == 5)
{
    echo "
    <div class=\"allCards\">

    <div class=\"cards\">
    <div  > <img class=\"chef-img\" src='". $row['img']."' /></div> 
      <div class=\"container\">
     
        <h4>". $row['Name'] ." ID=".$row['ID']."</h4>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <div class=\"MoreInfo\"><a href=\"chef.php?ID=". $row['ID'] ."\">Details</a></div>
     </div>
    </div>
  
    
  </div>
    "
   ;
} 

}
?>
