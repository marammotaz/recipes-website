<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

session_start();

error_reporting(0);

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>chef page</title>
  <link rel="stylesheet" href="../Styles/chefRecipe.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>

  <div class="bar">
    <form class="example" action="home.php">
      <a class="logout-button" href="signin.php">
        <img src="https://img.icons8.com/ios-filled/50/ffffff/exit.png" class="log-img" />
        <div class="logout">LOGOUT</div>
      </a>
    </form>
  </div>



  <!-- Here is the form that we add a new recipe in it with the all recipe details needed-->
  <form id='fupForm' action="" method="POST">
    <div id="content">


      <!-- Here is the div that contain the img and headers which are in the top of the page -->
      <div class="recipe-img">

        <div class="blurBack">Add New Recipe </div>
      </div>
      <div class='addContainer'>
        <div id='lefttt'>

          <br>
          <div class="group">
            <!-- input for the id of the recipe -->
            <input type="text" required class="form-input" id='ID_Rec' name='ID_Rec' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>ID_Rec</label>
          </div>
          <!-- input for the name of the recipe -->
          <div class="group">
            <input type="text" required class="form-input" id='Name' name='Name' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Name</label>
          </div>

          <div class="group">
            <!-- input for the img of the recipe -->
            <input type="text" required class="form-input" id='img' name='img' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Img</label>
          </div>
          <div class="group">
            <!-- input for the time of the recipe -->
            <input type="text" required class="form-input" id='time' name='time' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>time</label>



          </div>
          <div class="group">
            <!-- input for the serving of the recipe -->
            <input type="text" required class="form-input" id='serve' name='serve' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>serve</label>

          </div>
          <div class="group">
            <!-- input for the of description of the recipe -->
            <input type="text" required class="form-input" id='Description' name='Description' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Description</label>

          </div>

          <div class="group">
            <!-- input for the of prepration time of the recipe -->
            <input type="text" required class="form-input" id='preptime' name='preptime' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>preptime</label>


          </div>


          <div class="group">
            <!-- input for the of category of the recipe -->
            <input type="text" required class="form-input" id='category' name='category' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>category</label>

          </div>




          <!-- inputs for the NUTRITIONFACT of the recipes -->
          <div class="group">
            <input type="text" required class="form-input" id='NUTRITIONFACT1' name='NUTRITIONFACT1' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>NUTRITIONFACT1</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='NUTRITIONFACT2' name='NUTRITIONFACT2' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>NUTRITIONFACT2</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='NUTRITIONFACT3' name='NUTRITIONFACT3' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>NUTRITIONFACT3</label>
          </div>


          <div class="group">
            <input type="text" required class="form-input" id='NUTRITIONFACT4' name='NUTRITIONFACT4' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>NUTRITIONFACT4</label>
          </div>


          <div class="group">
            <input type="text" required class="form-input" id='NUTRITIONFACT5' name='NUTRITIONFACT5' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>NUTRITIONFACT5</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='NUTRITIONFACT6' name='NUTRITIONFACT6' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>NUTRITIONFACT6</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='Filter' name='Filter' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Filter</label>

          </div>
        </div>



        <div id='right'>

          <div class="group">
            <!-- input for the chef_id of the recipes -->
            <input type="text" required class="form-input" id='chef_id' name='chef_id' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Chef_id</label>

          </div>
          <!-- inputs for the INSTRUCTIONS of the recipes -->
          <div class="group">

            <input type="text" required class="form-input" id='INSTRUCTION1' name='INSTRUCTION1' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INSTRUCTION1</label>

          </div>
          <div class="group">

            <input type="text" required class="form-input" id='INSTRUCTION2' name='INSTRUCTION2' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INSTRUCTION2</label>
          </div>

          <div class="group">

            <input type="text" required class="form-input" id='INSTRUCTION3' name='INSTRUCTION3' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INSTRUCTION3</label>
          </div>

          <!-- inputs for the INGREDIENTS of the recipes -->

          <div class="group">
            <input type="text" required class="form-input" id='INGREDIENT1' name='INGREDIENT1' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INGREDIENT1</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='INGREDIENT2' name='INGREDIENT2' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INGREDIENT2</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='INGREDIENT3' name='INGREDIENT3' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INGREDIENT3</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='INGREDIENT4' name='INGREDIENT4' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INGREDIENT4</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='INGREDIENT5' name='INGREDIENT5' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INGREDIENT5</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='INGREDIENT6' name='INGREDIENT6' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INGREDIENT6</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='INGREDIENT7' name='INGREDIENT7' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>INGREDIENT7</label>
          </div>

          <!-- inputs for the tools need for the recipes -->
          <div class="group">
            <input type="text" required class="form-input" id='Tool1' name='Tool1' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Tool1</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='Tool2' name='Tool2' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Tool2</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='Tool3' name='Tool3' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Tool3</label>
          </div>

          <div class="group">
            <input type="text" required class="form-input" id='Tool4' name='Tool4' />
            <span class="highlight"></span>
            <span class="barContact"></span>
            <label>Tool4</label>
          </div>








        </div>
      </div>








      <button class="btnChef" name='submit' id='addrec'>Add Recipe</button>
      <br>
      <br>
      <br>
      <br>
      <br>
    </div>
  </form>


  <!-- Includes the footer -->
  <?php include 'footer.php' ?>

  <script>
    // by click on the button we store the values of the inputs to post them in all add recipe page
    // that will display them in all recipe page
    $("#addrec").click(function() {
      var ID_Rec = $("#ID_Rec").val();
      var Name = $("#Name").val();

      var img = $("#img").val();
      var time = $("#time").val();
      var serve = $("#serve").val();
      var Description = $("#Description").val();
      var preptime = $("#preptime").val();
      var category = $("#category").val();
      var chef_id = $("#chef_id").val();
      //alert(chef_id);
      var INSTRUCTION1 = $("#INSTRUCTION1").val();
      var INSTRUCTION2 = $("#INSTRUCTION2").val();
      var INSTRUCTION3 = $("#INSTRUCTION3").val();

      var NUTRITIONFACT1 = $("#NUTRITIONFACT1").val();
      var NUTRITIONFACT2 = $("#NUTRITIONFACT2").val();
      var NUTRITIONFACT3 = $("#NUTRITIONFACT3").val();
      var NUTRITIONFACT4 = $("#NUTRITIONFACT4").val();
      var NUTRITIONFACT5 = $("#NUTRITIONFACT5").val();
      var NUTRITIONFACT6 = $("#NUTRITIONFACT6").val();

      var INGREDIENT1 = $("#INGREDIENT1").val();
      var INGREDIENT2 = $("#INGREDIENT2").val();
      var INGREDIENT3 = $("#INGREDIENT3").val();
      var INGREDIENT4 = $("#INGREDIENT4").val();
      var INGREDIENT5 = $("#INGREDIENT5").val();
      var INGREDIENT6 = $("#INGREDIENT6").val();
      var INGREDIENT7 = $("#INGREDIENT7").val();
      var Tool1 = $("#Tool1").val();
      var Tool2 = $("#Tool2").val();
      var Tool3 = $("#Tool3").val();
      var Tool4 = $("#Tool4").val();
      var Filter = $("#Filter").val();
      $.ajax({
        url: 'addrec.php',
        method: 'POST',
        data: {
          ID_Rec: ID_Rec,
          chef_id: chef_id,
          Name: Name,
          img: img,
          time: time,
          serve: serve,
          Description: Description,
          preptime: preptime,
          category: category,
          INSTRUCTION1: INSTRUCTION1,
          INSTRUCTION2: INSTRUCTION2,
          INSTRUCTION3: INSTRUCTION3,
          NUTRITIONFACT1: NUTRITIONFACT1,
          NUTRITIONFACT2: NUTRITIONFACT2,
          NUTRITIONFACT3: NUTRITIONFACT3,
          NUTRITIONFACT4: NUTRITIONFACT4,
          NUTRITIONFACT5: NUTRITIONFACT5,
          NUTRITIONFACT6: NUTRITIONFACT6,
          INGREDIENT1: INGREDIENT1,
          INGREDIENT2: INGREDIENT2,
          INGREDIENT3: INGREDIENT3,
          INGREDIENT4: INGREDIENT4,
          INGREDIENT5: INGREDIENT5,
          INGREDIENT6: INGREDIENT6,
          INGREDIENT7: INGREDIENT7,
          Tool1: Tool1,
          Tool2: Tool2,
          Tool3: Tool3,
          Tool4: Tool4,
          Filter: Filter

        },
        success: function(response) {
          alert(response);
        }
      });
    });
  </script>
</body>

</html>