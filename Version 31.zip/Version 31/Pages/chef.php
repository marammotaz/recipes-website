<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Chef</title>
  <link rel="stylesheet" href="../Styles/chefs.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>
  <!-- Includes the navbar -->
  <?php include 'navbar.php'; ?>
  <?php

//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

//query to select by id
$sql = "SELECT * FROM chefs WHERE ID= " . $_GET["ID"] . "" ;
$result = mysqli_query($conn, $sql) ;
$row = $result ->fetch_assoc();

//get the details of each chef in chefs table from database by his id and display it


if ( isset( $_GET[ "ID" ] ) ){
  
  //the if conditions to handle the icons of the rating bar
  if($row['rating'] == 1) {
    /* creating the div of details of the chef with his rounded img, name, rating with rating icons, nationality, 
    number of recipes , his books and paragraph for description of chef */
    echo "
    <div class=\"detailsContainer\">
    <div  ><img class=\"rounded-img\" src='". $row['img']."' /></div> 
    <div class=\"moredetails\">
      <h3>". $row['Name'] ."</h3>
      <div class=\"rating\">
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
      </div>
      <br>
      <div class=\"text\">
        <p>
          <label class=\"Nationality\"><strong style=\"color: lightgreen;\">Nationality: </strong>". $row['Nationality'] ." </label>
          <br>
          <label class=\"Numrecipes\"><strong style=\"color: lightgreen;\">Number of Recipes: </strong> ". $row['NumberOfRecipes'] ." </label>
          <br>
          <label class=\"books\"><strong style=\"color: lightgreen;\">Books: </strong>
            <ul class=\"ul-style\">
              <li>". $row['Books'] ."</li>
              <li>". $row['book2'] ."</li>
              <li>". $row['book3'] ."</li>
            </ul>
          </label>
      </div>
      <p class=\"description\">". $row['Description'] ." </p>
      <br>
  </div>
    "; } 
  if($row['rating'] == 2) {
    echo "
    <div class=\"detailsContainer\">
    <div  ><img class=\"rounded-img\" src='". $row['img']."' /></div> 
    <div class=\"moredetails\">
      <h3>". $row['Name'] ."</h3>
      <div class=\"rating\">
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
      </div>
      <br>
      <div class=\"text\">
        <p>
          <label class=\"Nationality\"><strong style=\"color: lightgreen;\">Nationality: </strong>". $row['Nationality'] ." </label>
          <br>
          <label class=\"Numrecipes\"><strong style=\"color: lightgreen;\">Number of Recipes: </strong> ". $row['NumberOfRecipes'] ." </label>
          <br>
          <label class=\"books\"><strong style=\"color: lightgreen;\">Books: </strong>
            <ul class=\"ul-style\">
              <li>". $row['Books'] ."</li>
              <li>". $row['book2'] ."</li>
              <li>". $row['book3'] ."</li>
            </ul>
          </label>
      </div>
      <p class=\"description\">". $row['Description'] ." </p>
      <br>
  </div>
    "; }

  if($row['rating'] == 3) {
    echo "
    <div class=\"detailsContainer\">
    <div  ><img class=\"rounded-img\" src='". $row['img']."' /></div> 
    <div class=\"moredetails\">
      <h3>". $row['Name'] ."</h3>
      <div class=\"rating\">
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star checked\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
      </div>
      <br>
      <div class=\"text\">
        <p>
          <label class=\"Nationality\"><strong style=\"color: lightgreen;\">Nationality: </strong>". $row['Nationality'] ." </label>
          <br>
          <label class=\"Numrecipes\"><strong style=\"color: lightgreen;\">Number of Recipes: </strong> ". $row['NumberOfRecipes'] ." </label>
          <br>
          <label class=\"books\"><strong style=\"color: lightgreen;\">Books: </strong>
            <ul class=\"ul-style\">
              <li>". $row['Books'] ."</li>
              <li>". $row['book2'] ."</li>
              <li>". $row['book3'] ."</li>
            </ul>
          </label>
      </div>
      <p class=\"description\">". $row['Description'] ." </p>
      <br>
  </div>
    "; } else if ($row['rating'] == 4) {
      echo "
      <div class=\"detailsContainer\">
      <div > <img class=\"rounded-img\" src='". $row['img']."' /></div> 
      <div class=\"moredetails\">
        <h3>". $row['Name'] ."</h3>
        <div class=\"rating\">
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star-o\" aria-hidden=\"true\"></span>
        </div>
        <br>
        <div class=\"text\">
          <p>
            <label class=\"Nationality\"><strong style=\"color: lightgreen;\">Nationality: </strong>". $row['Nationality'] ." </label>
            <br>
            <label class=\"Numrecipes\"><strong style=\"color: lightgreen;\">Number of Recipes: </strong> ". $row['NumberOfRecipes'] ." </label>
            <br>
            <label class=\"books\"><strong style=\"color: lightgreen;\">Books: </strong>
              <ul class=\"ul-style\">
                <li>". $row['Books'] ."</li>
                <li>". $row['book2'] ."</li>
                <li>". $row['book3'] ."</li>
              </ul>
            </label>
        </div>
        <p class=\"description\">". $row['Description'] ." </p>
        <br>
    </div>
      ";

    } else if  ($row['rating'] == 5){
      echo "
      <div class=\"detailsContainer\">
      <div ><img class=\"rounded-img\"  src='". $row['img']."' /></div> 
      <div class=\"moredetails\">
        <h3>". $row['Name'] ."</h3>
        <div class=\"rating\">
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star checked\"></span>
          <span class=\"fa fa-star checked\"></span>
        </div>
        <br>
        <div class=\"text\">
          <p>
            <label class=\"Nationality\"><strong style=\"color: lightgreen;\">Nationality: </strong>". $row['Nationality'] ." </label>
            <br>
            <label class=\"Numrecipes\"><strong style=\"color: lightgreen;\">Number of Recipes: </strong> ". $row['NumberOfRecipes'] ." </label>
            <br>
            <label class=\"books\"><strong style=\"color: lightgreen;\">Books: </strong>
              <ul class=\"ul-style\">
                <li>". $row['Books'] ."</li>
                <li>". $row['book2'] ."</li>
                <li>". $row['book3'] ."</li>
              </ul>
            </label>
        </div>
        <p class=\"description\">". $row['Description'] ." </p>
        <br>
    </div>
      ";
    }
}
?> 
</div>
<!-- Includes the footer -->
<?php include 'footer.php'; ?>
</body>
</html>