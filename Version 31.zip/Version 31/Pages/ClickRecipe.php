<?php 

session_start();

// Check whether the user has previously login before proceeding to this page or not
if (!isset($_SESSION['username'])) {
    header("Location: signin.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <link rel="stylesheet" href="../Styles/RecipeDetails.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
</head>
<title>Recipe Details</title>
</head>

<body>
  <?php include 'navbar.php'; ?>
  <?php

//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

// query to select recipe by its ID 
$query ="SELECT * FROM recipe WHERE ID_Rec=".$_GET["ID_Rec"]." " ;
$result = mysqli_query($conn, $query) ;
// to fetch data and details from the database 
$row = $result ->fetch_assoc();
/* check on the ID and create a card with details of the recipe which are the img, name, preparation time, cook time 
   then the ingredients , intructions , tools and nutrition facts about the recipe
*/
  if ( isset( $_GET[ "ID_Rec" ] ) ) {
        echo "
        <div class=\"Recipiedetailsbody\">
        <div class=\"recipe-page\">
        <div class=\"recipe-hero\">
        <div class='center'><img src=".$row['img']."  class=\"image recipeinfo-img\" /></div>
         <article class=\"recipe-info\">
          <h1 class=\"RecinfoName\">".$row['Name']."</h1>
          <h1 class=\"cheffID\"> Made By Chef Id: ".$row['chef_id']."</h1>
          <p class=\"breifnote\"> ".$row['Description']."</p>
           <div class=\"recipe-icons\">
          <article>
              <i class=\"fas fa-clock\"></i>
              <h5 class=\"headt\">prep time</h5>
              <p class=\"timedec\">".$row['preptime']."</p>
           </article>
            <article>
              <i class=\"far fa-clock\"></i>
              <h5 class=\"headt\">cook time</h5>
              <p class=\"timedec\">".$row['time']."</p>
            </article>
             <article>
              <i class=\"fas fa-user-friends\"></i>
              <h5 class=\"headt\">Serving</h5>	
              <p class=\"timedec\">".$row['serve']."</p>
            </article>
          </div>
         </article>
        </div>
   
        <section class=\"recipe-content\">

         <article class=\"Ingred\">
          <div>
            <h3 class=\"HeadIngToo\">Ingredients</h3>
            <p class=\"single-ingredient\">".$row['INGREDIENT1']."</p>
            <p class=\"single-ingredient\">".$row['INGREDIENT2']."</p>
            <p class=\"single-ingredient\">".$row['INGREDIENT3']."</p>
            <p class=\"single-ingredient\">".$row['INGREDIENT4']."</p>
            <p class=\"single-ingredient\">".$row['INGREDIENT5']."</p>
            <p class=\"single-ingredient\">".$row['INGREDIENT6']."</p>
            <p class=\"single-ingredient\">".$row['INGREDIENT7']."</p>
          </div>

          <div class=\"endnew\">
            <div class=\"lineend\">
              <i id=\"section-icon\" class=\"fa fa-spoon fa-3x\"></i>
            </div>
          </div>
          <div>
            <h3 class=\"HeadIngToo\">Tools</h3>
            <p>
            <ul class=\"liststyletools\">
              <li class=\"single-tool\">".$row['Tool1']."</li>
              <li class=\"single-tool\">".$row['Tool2']."</li>
              <li class=\"single-tool\">".$row['Tool3']."</li>
              <li class=\"single-tool\">".$row['Tool4']."</li>
            </ul>
            </p>
          </div>

          <div class=\"endnew\">
            <div class=\"lineend\">
              <i id=\"section-icon\" class=\"fa fa-spoon fa-3x\"></i>
            </div>
        </article>

        <article>
        <br><br>
          <h3 class=\"HeadIngToo\">Instructions</h3>

          <div class=\"single-instruction\">
            <header>
              <p class=\"stepsing\"> <i class=\"fas fa-check-circle\"></i>
                Step 1</p>
              <div></div>
            </header>
            <p class=\"descsteps\">".$row['INSTRUCTION1']."</p>
          </div>
       
          <!-- single instruction -->
          <div class=\"single-instruction\">
            <header>
              <p class=\"stepsing\"> <i class=\"fas fa-check-circle\"></i>
                Step 2</p>
              <div></div>
            </header>
            <p class=\"descsteps\">".$row['INSTRUCTION2']."</p>
          </div>
          <!-- end of single instruction -->

          <!-- single instruction -->
          <div class=\"single-instruction\">
            <header>
              <p class=\"stepsing\"> <i class=\"fas fa-check-circle\"></i>
                Step 3</p>
              <div></div>
            </header>
            <p class=\"descsteps\">".$row['INSTRUCTION3']."</p>
      
          </div>
          <!-- end of single instruction -->

        </article>
        <br> <br>
        <!-- the hr with spoon -->
        <div class=\"endnew\">
          <div class=\"lineend\">
            <i id=\"section-icon\" class=\"fa fa-spoon fa-3x\"></i>
          </div>
          <article class=\"Ingred\">
            <div>
              <br> <br>
              <h3 class=\"HeadIngToo\">Nutrition Facts</h3>
              <ol>
                <li class=\"single-ingredient\">".$row['NUTRITIONFACT1']."</li>
                <li class=\"single-ingredient\">".$row['NUTRITIONFACT2']."</li>
                <li class=\"single-ingredient\">".$row['NUTRITIONFACT3']."</li>
                <li class=\"single-ingredient\">".$row['NUTRITIONFACT4']."</li>
                <li class=\"single-ingredient\">".$row['NUTRITIONFACT5']."</li>
                <li class=\"single-ingredient\">".$row['NUTRITIONFACT6']."</li>
              </ol>
            </div>
            <br> 
            </article>
           </section>
           </div>
          </div>
          ";
      }
         
          
?>
<?php include 'footer.php'; ?>
</body>

</html>