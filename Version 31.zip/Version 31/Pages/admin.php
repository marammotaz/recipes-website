<?php 
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

session_start();

error_reporting(0);

?>

 <!DOCTYPE html>
<html lang="en" dir="ltr"> 
<head>
  <meta charset="utf-8">
  <title>Admin Page</title>
  <link rel="stylesheet" href="../Styles/admin.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
  <!-- Here is the table that we show in it the comments of user -->
  <div class= 'container'>

<div class='leftt'>

<div class='title-comments'>Comments of the Users</div>
<div class='table_container'>
        <table class= 'table'>
        <thead>
                <tr>
                    <th scope='col'>Name</th>
                    <th scope='col'>Email</th>
                    <th scope='col'>Comments</th>
                    <th scope='col'> Time of Comment</th>

                </tr>
            </thead>
            <tbody id='bodyy'>
            </tbody>
        </table>
    </div>
  <button class='btn' id='show'> Show Comments</button>

  </div>


<div class="container_outer_img">
<div class="bar">
        <form class="example" action="admin.php">
            <!-- Here is the logout button which when press on it it will return back to the sign in page -->
          <a class="logout-button" href="signin.php"> 
            <img src="https://img.icons8.com/ios-filled/50/ffffff/exit.png" class="log-img"/>
            <div class="logout">LOGOUT</div> 
          </a>
        </form> 
      </div>

         <div class="beforeGrid">


  <!-- Here is the form that we add a new chef in it with the all chef details needed-->
<form id='fupForm' action="" method="POST">
  <div id="content">
     <div class="marg"></div>
    <h2 class="align-top">Add New Chef</h2>
  <br> 
    <div class="group">
  <!-- input for the id of the chef -->
      <input type="text" required class="form-input" id='ID' name='ID'/>
      <span class="highlight"></span>
      <span class="barContact"></span>
      <label>ID</label>
    </div>
  <!-- input for the name chef -->
    <div class="group">
      <input type="text" required class="form-input" id='Name' name='Name'/>
      <span class="highlight"></span>
      <span class="barContact"></span>
      <label>Name</label>
    </div>
    <div class="group">
  <!-- input for the rating of the chef -->
      <input type="text" required class="form-input" id='rating' name='rating'/> 
      <span class="highlight"></span>
      <span class="barContact"></span>
      <label>rating</label>

    </div>
    <div class="group">
  <!-- input for the img of the chef -->
<input type="text" required class="form-input" id='img' name='img'/> 
<span class="highlight"></span>
<span class="barContact"></span>
<label>Img</label>


</div>
<div class="group">
  <!-- input for the nationality of the chef -->
<input type="text" required class="form-input" id='Nationality' name='Nationality'/> 
<span class="highlight"></span>
<span class="barContact"></span>
<label>Nationality</label>

</div>
<div class="group">
  <!-- input for the number of recipes of the chef -->
<input type="text" required class="form-input" id='NumberOfRecipes' name='NumberOfRecipes'/> 
<span class="highlight"></span>
<span class="barContact"></span>
<label>NumberOfRecipes</label>

</div>
  <!-- inputs for the books of the chef -->
<div class="group">

<input type="text" required class="form-input" id='Books' name='Books'/> 
<span class="highlight"></span>
<span class="barContact"></span>
<label>book1</label>


</div>


<div class="group">

<input type="text" required class="form-input" id='book2' name='book2'/> 
<span class="highlight"></span>
<span class="barContact"></span>
<label>book2</label>

</div>

<div class="group">

<input type="text" required class="form-input" id='book3' name='book3'/> 
<span class="highlight"></span>
<span class="barContact"></span>
<label>book3</label>

</div>
<div class="group">
  <!-- input for the description of the chef -->
<input type="text" required class="form-input" id='Description' name='Description'/> 
<span class="highlight"></span>
<span class="barContact"></span>
<label>Description</label>



</div>
    <button class="btnChef" name='submit' id='addcheff'>Add Chef</button>
    <br>
    <br>
  </div>
</form>
</div>
</div>
</div>
  <!-- Here is the feedback img -->
<div class="img-inner">
     <img src='../Media/feedback (1).png' alt="" class="container_img"/>
           </div>
         </div>
</div>
<div class="overlay"></div>
  <!-- Includes the footer -->
  <?php include 'footer.php' ?>

  <script>


        $(document).ready(function(){
            $("#show").click(function(){
       

         // here is the ajax function to get the details of chef from the database
                $.ajax({
                    url:'adminComments.php',
                    method:'GET',

                   success:function(response){
                    $("#bodyy").html(response); 
                   }
                  });
                });
        // by click on the button we store the values of the inputs to post them in all chefs page
             $("#addcheff").click(function(){
              var ID=$("#ID").val();
                var Name=$("#Name").val();
                var rating=$("#rating").val();
                var img=$("#img").val();
                var Nationality=$("#Nationality").val();
                var NumberOfRecipes=$("#NumberOfRecipes").val();
                var Books=$("#Books").val();
                var book2=$("#book2").val();
                var book3=$("#book3").val();
                var Description=$("#Description").val();
                
                $.ajax({
                    url:'addchef.php',
                    method:'POST',
                    data:{
                        ID:ID,
                        Name:Name,
                        rating:rating,
                        img:img,
                        Nationality:Nationality,
                        NumberOfRecipes:NumberOfRecipes,
                        Books:Books,
                        book2:book2,
                        book3:book3,
                        Description:Description




                    },
          success:function(response){
            alert(response);
          }
                });
            });
          });

  </script>
</body>

</html>