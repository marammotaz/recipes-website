<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

    $sql = "SELECT * FROM comments";
    $result = mysqli_query($conn, $sql);
    //get the details of each comment of user in comments table from database and display it
	while ($row = $result->fetch_assoc()) {
        echo "
            <tr>
            <td data-label='Name' scope='row'> " . $row['name'] . "</td>
            <td data-label='Email'> " . $row['email'] . "</td>
            <td data-label='Comments'>  "  . $row['content'] . "</td>
            <td data-label='Time'> " . $row['currentTime'] . "</td>
           
        </tr>"
      
  ;
    
    }
?>
 