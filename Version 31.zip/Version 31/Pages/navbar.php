<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../Styles/navbar.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <title>Navbar</title>
</head>

<body>
  <!-- Here is the navbar shown the the top of the pages -->
  <div class="navbar">
    <div class="navbar-head">
      <!-- Here is the logo shwon the the left of the navbar -->
      <img src="../Media/logo.png" alt="logo" class="left-logo" />
      <!-- Here are the references to another pages -->
      <nav class="stroke">
        <ul> 
          <li><a href="home.php" id="home">Home</a></li>
          <li><a href="AllRecipes.php?category=none" id="recipes">All Recipes</a></li>
          <li><a href="Allchefs.php" id="chefs">All Chefs</a></li>
          <li><a href="Contact_us.php" id="contact">Contact Us</a></li>
        </ul>
      </nav>
      
      <!-- Here is the button of the logout -->
      <div class="bar">
        <form class="example" action="home.php">
          <a class="logout-button" href="signin.php"> 
            <img src="https://img.icons8.com/ios-filled/50/ffffff/exit.png" class="log-img"/>
            <div class="logout">LOGOUT</div> 
          </a>
        </form> 
      </div>
    </div>
    <!-- Here is the line seperating navbar from body -->
    <hr class="hr-style-nav" />
    <br/>
  </div>

</body>

</html>