<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';
error_reporting(0);

$fullName = $_POST['fullName'];
$birthDate = $_POST['birthDate'];
$username = $_POST['username'];
$password = $_POST['pass'];

// Check whether any usernames in the database have the same one as written or not
$sql = "SELECT * FROM users WHERE username='$username'";
$result = mysqli_query($conn, $sql);

if (!$result->num_rows > 0) {
  // Insert a new tuple in the database
  $sql = "INSERT INTO users (fullName,birthDate,username, password)
        VALUES ('$fullName','$birthDate', '$username', '$password')";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    // Go to sign in page
    echo 'success';
  } 
} else {
  // Show to the user an error message indicating that this username is not available
  echo 'failed';
}
