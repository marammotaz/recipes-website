<?php
//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

session_start();

error_reporting(0);

$username = $_POST['username'];
$password = $_POST['pass'];

// Check whether there exists any user that has the same username and password
$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = mysqli_query($conn, $sql);

if ($result->num_rows > 0) {
  // Go to home page and make variable username with the username entered
  $row = mysqli_fetch_assoc($result);
  $_SESSION['username'] = $row['username'];
  echo 'success';
} else {
  // Show to the user an error message indicating that this username or password is wrong
  echo 'invalid';
}
