<?php

//********* MazennnnnnnnnnnS' *********//
include 'D:/Php my admin/xampp/htdocs/php_projects/version 30/config/conn_database.php';
//********* Nardineeeeees' *********//
//include  'C:\xampp\htdocs\Version 26\config\conn_database.php';
//********* nouraannns' *********//
//include 'D:\xamppp\htdocs\Version 29\config\conn_database.php';
//********* maraaaamms' *********//
//include  'C:\xampp\htdocs\Version 28\config\conn_database.php';

session_start();

error_reporting(0);

// Intialize global variable username to null, to make sure user first login before going to home page
$_SESSION['username'] = null;
//localStorage.setItem("admin", null);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../Styles/sign.css" />
  <title>Login</title>
</head>

<body>
  <!-- Here is the card shown in the middle of the page -->
  <div class="card card-in" id="card">

    <!-- Here is the left of the card which has the image -->
    <div class="left">
      <div class="overlay" id="in"></div>
    </div>

    <!-- Here is the right of the card which contain the form -->
    <div class="right">
      <!-- Here is the Reme's logo -->
      <div class="reme-div">
        <img src="../Media/logo.png" alt="rat" class="newlogo" />
      </div>
      <!-- Here is the title of the page -->
      <h2 class="align-top">Login</h2>
      <!-- To check whether this is a new user or not -->
      <div class="acc">
        <span class="login">Don't have an account?
          <a href="signup.php">Register now</a></span>
      </div>
      <br />
      <br />
      <!-- Error message that has initially display none -->
      <div class="invalid" id="invalid">
        Please check your username or password
      </div>

      <div class="invalid" id="invalid-1">
      Username field is required
      </div>
      <!-- Here is the beginning of the form for user to enter his/her details -->
      <div id="content">
        <div class="marg"></div>
        <div class="group">
          <input type="text" required class="shrink" name="username" id="username" />
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>Username</label>
        </div>
        <div class="invalid" id="invalid-2">
        Password field is required
        </div>
        <div class="group">
          <input type="password" required class="shrink" name="password" id="pass"/>
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>Password</label>
        </div>
        <button class="btn" name="login" id="submit-btn">Submit</button>

      </div>
    </div>
  </div>
</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js" integrity="sha512-DkPsH9LzNzZaZjCszwKrooKwgjArJDiEjA5tTgr3YX4E6TYv93ICS8T41yFHJnnSmGpnf0Mvb5NhScYbwvhn2w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TimelineMax.min.js" integrity="sha512-0xrMWUXzEAc+VY7k48pWd5YT6ig03p4KARKxs4Bqxb9atrcn2fV41fWs+YXTKb8lD2sbPAmZMjKENiyzM/Gagw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
  const card = document.querySelector("#card");
  const img = document.querySelector(".left");
  const t1 = new TimelineMax();

  t1.fromTo(card, 2, {
      opacity: "0"
    }, {
      opacity: "1",
      ease: Power2.easeInOut
    })
    .fromTo(img, 1, {
      x: "-100%"
    }, {
      x: "0%",
      ease: Power2.easeInOut
    }, '-=1')
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>

  $(document).ready(function() {

    document.querySelector('#submit-btn').addEventListener('click', () => {
      
      const username=document.querySelector('#username').value
      const pass=document.querySelector('#pass').value
      if(username==""){
        document.querySelector('#invalid-1').style.display="block"
      }
      else{
        document.querySelector('#invalid-1').style.display="none"
      }
      if(pass==""){
        document.querySelector('#invalid-2').style.display="block"
      }
      else{
        document.querySelector('#invalid-2').style.display="none"
      }

      if(username!=""&& pass!=""){
        if((username=="admin") && (pass=="admin")){
  
          window.location.href = "admin.php";
        }
        else if ((username=="chef") && (pass=="chef")) {
          window.location.href = "chefRecipe.php";

        }
        $.ajax({
          url: "signin_verification.php",
          method: "POST",
          data: {
            username: username,
            pass:pass
          },

          success: function(data) {
            if(data=="success"){
              window.location.href = "home.php";
            }
            else{
              document.querySelector('#invalid').style.display="block"
            }
          }
        })
      }

    });
  })
</script>

</html>