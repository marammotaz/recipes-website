<?php 

$server = "localhost";
$user = "root";
$pass = "";
$database = "log_test";

$conn = mysqli_connect($server, $user, $pass, $database,"3307");

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}

?>
